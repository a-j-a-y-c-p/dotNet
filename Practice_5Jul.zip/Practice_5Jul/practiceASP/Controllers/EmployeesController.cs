﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using practiceASP.Models;

namespace practiceASP.Controllers
{
    public class EmployeesController : Controller
    {
        // GET: EmployeesController
        public ActionResult Index()
        {
            List<Employee> emp = Employee.GetAllEmployes();

            return View(emp);
        }

        // GET: EmployeesController/Details/5
        public ActionResult Details(int id)
        {
            Employee emp = Employee.getSingleEmployee(id);
            return View(emp);
        }

        // GET: EmployeesController/Create
        public ActionResult Create()
        {
            return View();
        }


        //  METHOD 1 --> using IFormCollection

        //public ActionResult Create(IFormCollection collection)
        //{
        //    try
        //    {
        //        //int EmpNo = int.Parse(collection["EmpNo"]);
        //        //string Name = collection["Name"];
        //        //decimal Basic = decimal.Parse(collection["Basic"]);
        //        //int DeptNo = int.Parse(collection["DeptNo"]);
        //        //Console.WriteLine(EmpNo);
        //        //Console.WriteLine(Name);
        //        //Console.WriteLine(Basic);
        //        //Console.WriteLine(DeptNo);
        //        return RedirectToAction(nameof(Index));
        //    }
        //    catch
        //    {
        //        return View();
        //    }
        //}


        // Method 2 --> using binding (input name should be same as HTML name attribute)
        //public ActionResult Create(int EmpNo, string Name, decimal Basic, int DeptNo)
        //{
        //    try
        //    {

        //        return RedirectToAction(nameof(Index));
        //    }
        //    catch
        //    {
        //        return View();
        //    }
        //}


        // POST: EmployeesController/Create
        [HttpPost]
        [ValidateAntiForgeryToken]

        // Method 3 --> using Model binding (Property names of model should be same as Html name attribute)
        public ActionResult Create(Employee emp)
        {
            try
            {
                Employee.Insert(emp);
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }



        // GET: EmployeesController/Edit/5
        public ActionResult Edit(int id)
        {
            return View();
        }

        // POST: EmployeesController/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(int id, IFormCollection collection)
        {
            try
            {
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }

        // GET: EmployeesController/Delete/5
        public ActionResult Delete(int id)
        {
            return View();
        }

        // POST: EmployeesController/Delete/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Delete(int id, IFormCollection collection)
        {
            try
            {
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }
    }
}
